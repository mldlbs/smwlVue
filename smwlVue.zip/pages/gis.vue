<template>
  <div class="container">
    <div />
  </div>
</template>

<script>
export default {
  layout: 'Gis',
  components: {
  },
  mounted () {
    // this.initData()
  },
  methods: {
    initData () {
    }
  }
}
</script>

<style>
  .container {
    margin: 0 auto;
    min-height: 100vh;
    display: flex;
    justify-content: center;
    align-items: center;
    text-align: center;
  }
</style>
