import Vue from 'vue'
import Router from 'vue-router'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _2e5688a2 = () => interopDefault(import('..\\pages\\gis.vue' /* webpackChunkName: "pages_gis" */))
const _744655f3 = () => interopDefault(import('..\\pages\\plot.vue' /* webpackChunkName: "pages_plot" */))
const _7adc92b0 = () => interopDefault(import('..\\pages\\index.vue' /* webpackChunkName: "pages_index" */))

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: decodeURI('/'),
  linkActiveClass: 'nuxt-link-active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/gis",
    component: _2e5688a2,
    name: "gis"
  }, {
    path: "/plot",
    component: _744655f3,
    name: "plot"
  }, {
    path: "/",
    component: _7adc92b0,
    name: "index"
  }],

  fallback: false
}

export function createRouter () {
  return new Router(routerOptions)
}
